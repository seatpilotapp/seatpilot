import React from 'react'

const SingleBad = () => {

  return (
    <g>
        <rect x={0} y={0} width={70} height={150} rx={6} stroke='#111827' strokeWidth={2} fill='white' />
        <line x1={0} y1={30} x2={70} y2={30} stroke='#111827' strokeWidth={2}/>
        <rect x={15} y={10} width={40} height={20} rx={4} stroke='#111827' strokeWidth={2} fill='white' />
    </g>
  )
}

export default SingleBad