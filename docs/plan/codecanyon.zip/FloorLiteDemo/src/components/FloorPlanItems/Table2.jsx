import React from 'react'

const Table2 = () => {

  return (
      <g>
          <rect x={0} y={0} width={60} height={90} rx={2} stroke='#111827' strokeWidth={2} fill='white' />
      </g>
  )
}

export default Table2