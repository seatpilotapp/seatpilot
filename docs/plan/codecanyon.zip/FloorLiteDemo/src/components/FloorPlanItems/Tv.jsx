import React from 'react'

const Tv = () => {

  return (
    <g>
       <rect x={0} y={0} width={130} height={40} rx={1} stroke='#111827' strokeWidth={2} fill='white'></rect>
       <rect x={30} y={15} width={70} height={6} rx={2} stroke='#111827' strokeWidth={2} fill='white'></rect>
       <rect x={35} y={20} width={60} height={3} rx={1} stroke='#111827' strokeWidth={2} fill='white'></rect>
     </g>
  )
}

export default Tv