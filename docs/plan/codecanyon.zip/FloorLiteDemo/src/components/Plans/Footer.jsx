import React from 'react'

const Footer = () => {
  return (
    <div className='text-slate-400 text-xs text-right'>
     FloorLite 2024
    </div>
  )
}

export default Footer