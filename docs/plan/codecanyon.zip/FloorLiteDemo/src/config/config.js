const config = {
  minScale: 0.5,
  maxScale: 3,
  gridArea: 1000,
  gridSize: 10,
  snapGridSize: 5,
  snapRotation: 5
}

export default config;


