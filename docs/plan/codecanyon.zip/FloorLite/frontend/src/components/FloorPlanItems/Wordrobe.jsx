import React from 'react'

const Sink = () => {

  return (
     <g>
        <rect x="0" y="0" width="130" height="60" rx="2" stroke='#111827' strokeWidth={2} fill='white'></rect>
        <rect x="0" y="55" width="130" height="5" rx="1" stroke='#111827' strokeWidth={2} fill='white'></rect>
        <rect x="0" y="55" width="80" height="5" rx="1" stroke='#111827' strokeWidth={2} fill='white'></rect>
      </g>
  )
}

export default Sink